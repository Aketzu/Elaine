create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.vod_group_format_links DROP CONSTRAINT vod_group;
ALTER TABLE ONLY public.programs DROP CONSTRAINT vod_group;
ALTER TABLE ONLY public.vod_group_format_links DROP CONSTRAINT vod_format;
ALTER TABLE ONLY public.vods DROP CONSTRAINT vod_format;
ALTER TABLE ONLY public.reference_log_entries DROP CONSTRAINT tape;
ALTER TABLE ONLY public.tape_program_links DROP CONSTRAINT tape;
ALTER TABLE ONLY public.tape_event_links DROP CONSTRAINT tape;
ALTER TABLE ONLY public.programs DROP CONSTRAINT status;
ALTER TABLE ONLY public.program_event_links DROP CONSTRAINT program;
ALTER TABLE ONLY public.broadcast_logs DROP CONSTRAINT program;
ALTER TABLE ONLY public.vods DROP CONSTRAINT program;
ALTER TABLE ONLY public.tape_program_links DROP CONSTRAINT program;
ALTER TABLE ONLY public.program_descriptions DROP CONSTRAINT program;
ALTER TABLE ONLY public.playlists DROP CONSTRAINT program;
ALTER TABLE ONLY public.tapes DROP CONSTRAINT "owner";
ALTER TABLE ONLY public.programs DROP CONSTRAINT "owner";
ALTER TABLE ONLY public.tapes DROP CONSTRAINT media;
ALTER TABLE ONLY public.events DROP CONSTRAINT "location";
ALTER TABLE ONLY public.program_descriptions DROP CONSTRAINT "language";
ALTER TABLE ONLY public.vods DROP CONSTRAINT file_location;
ALTER TABLE ONLY public.programs DROP CONSTRAINT file_location;
ALTER TABLE ONLY public.events DROP CONSTRAINT file_location;
ALTER TABLE ONLY public.events DROP CONSTRAINT event_type;
ALTER TABLE ONLY public.program_event_links DROP CONSTRAINT event;
ALTER TABLE ONLY public.tape_event_links DROP CONSTRAINT event;
ALTER TABLE ONLY public.reference_log_entries DROP CONSTRAINT channel;
ALTER TABLE ONLY public.broadcast_logs DROP CONSTRAINT channel;
ALTER TABLE ONLY public.playlists DROP CONSTRAINT channel;
ALTER TABLE ONLY public.tapes DROP CONSTRAINT category;
DROP INDEX public.sessions_session_id_index;
ALTER TABLE ONLY public.vods DROP CONSTRAINT vods_pkey;
ALTER TABLE ONLY public.vod_groups DROP CONSTRAINT vod_groups_pkey;
ALTER TABLE ONLY public.vod_group_format_links DROP CONSTRAINT vod_group_format_links_pkey;
ALTER TABLE ONLY public.vod_formats DROP CONSTRAINT vod_formats_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.tapes DROP CONSTRAINT tapes_pkey;
ALTER TABLE ONLY public.tape_program_links DROP CONSTRAINT tape_program_links_pkey;
ALTER TABLE ONLY public.tape_medias DROP CONSTRAINT tape_medias_pkey;
ALTER TABLE ONLY public.tape_event_links DROP CONSTRAINT tape_event_links_pkey;
ALTER TABLE ONLY public.tape_categories DROP CONSTRAINT tape_categories_pkey;
ALTER TABLE ONLY public.sessions DROP CONSTRAINT sessions_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.reference_log_entries DROP CONSTRAINT reference_log_entries_pkey;
ALTER TABLE ONLY public.programs DROP CONSTRAINT programs_pkey;
ALTER TABLE ONLY public.program_statuses DROP CONSTRAINT program_statuses_pkey;
ALTER TABLE ONLY public.program_event_links DROP CONSTRAINT program_event_links_pkey;
ALTER TABLE ONLY public.program_descriptions DROP CONSTRAINT program_descriptions_pkey;
ALTER TABLE ONLY public.playlists DROP CONSTRAINT playlists_pkey;
ALTER TABLE ONLY public.permissions DROP CONSTRAINT permissions_pkey;
ALTER TABLE ONLY public.people DROP CONSTRAINT people_pkey;
ALTER TABLE ONLY public.locations DROP CONSTRAINT locations_pkey;
ALTER TABLE ONLY public.languages DROP CONSTRAINT languages_pkey;
ALTER TABLE ONLY public.file_locations DROP CONSTRAINT file_locations_pkey;
ALTER TABLE ONLY public.events DROP CONSTRAINT events_pkey;
ALTER TABLE ONLY public.event_types DROP CONSTRAINT event_types_pkey;
ALTER TABLE ONLY public.channels DROP CONSTRAINT channels_pkey;
ALTER TABLE ONLY public.broadcast_logs DROP CONSTRAINT broadcast_logs_pkey;
DROP TABLE public.vods;
DROP TABLE public.vod_groups;
DROP TABLE public.vod_group_format_links;
DROP TABLE public.vod_formats;
DROP TABLE public.users_roles;
DROP TABLE public.users;
DROP TABLE public.tapes;
DROP TABLE public.tape_program_links;
DROP TABLE public.tape_medias;
DROP TABLE public.tape_event_links;
DROP TABLE public.tape_categories;
DROP TABLE public.sessions;
DROP TABLE public.schema_info;
DROP TABLE public.roles;
DROP TABLE public.reference_log_entries;
DROP TABLE public.programs;
DROP TABLE public.program_statuses;
DROP TABLE public.program_event_links;
DROP TABLE public.program_descriptions;
DROP TABLE public.playlists;
DROP TABLE public.permissions_roles;
DROP TABLE public.permissions;
DROP TABLE public.people;
DROP TABLE public.locations;
DROP TABLE public.languages;
DROP TABLE public.file_locations;
DROP TABLE public.events;
DROP TABLE public.event_types;
DROP TABLE public.engine_schema_info;
DROP TABLE public.channels;
DROP TABLE public.broadcast_logs;
DROP PROCEDURAL LANGUAGE plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: 
--

CREATE PROCEDURAL LANGUAGE plpgsql;


SET default_tablespace = '';

SET default_with_oids = true;

--
-- Name: broadcast_logs; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE broadcast_logs (
    id serial NOT NULL,
    start_time timestamp without time zone,
    program_id integer,
    channel_id integer DEFAULT 1
);


ALTER TABLE public.broadcast_logs OWNER TO elaine2;

--
-- Name: broadcast_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('broadcast_logs', 'id'), 13, true);


--
-- Name: channels; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE channels (
    id serial NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.channels OWNER TO elaine2;

--
-- Name: channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('channels', 'id'), 2, true);


--
-- Name: engine_schema_info; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE engine_schema_info (
    engine_name character varying(255),
    version integer
);


ALTER TABLE public.engine_schema_info OWNER TO elaine2;

--
-- Name: event_types; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE event_types (
    id serial NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.event_types OWNER TO elaine2;

--
-- Name: event_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('event_types', 'id'), 2, true);


--
-- Name: events; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE events (
    id serial NOT NULL,
    title character varying(255),
    script text,
    location_id integer DEFAULT 1,
    event_type_id integer,
    notes text,
    length integer,
    quarantine timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    filename character varying(255),
    file_location_id integer
);


ALTER TABLE public.events OWNER TO elaine2;

--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('events', 'id'), 260, true);


--
-- Name: file_locations; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE file_locations (
    id serial NOT NULL,
    name character varying(255),
    description text,
    url character varying(255),
    checker_url character varying(255)
);


ALTER TABLE public.file_locations OWNER TO elaine2;

--
-- Name: file_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('file_locations', 'id'), 5, true);


--
-- Name: languages; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE languages (
    id serial NOT NULL,
    name character varying(255),
    code character varying(255),
    compulsory boolean DEFAULT true
);


ALTER TABLE public.languages OWNER TO elaine2;

--
-- Name: languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('languages', 'id'), 2, true);


--
-- Name: locations; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE locations (
    id serial NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.locations OWNER TO elaine2;

--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('locations', 'id'), 5, true);


--
-- Name: people; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE people (
    id serial NOT NULL,
    name character varying(255),
    title character varying(255),
    organization character varying(255),
    phone character varying(255),
    email character varying(255)
);


ALTER TABLE public.people OWNER TO elaine2;

--
-- Name: people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('people', 'id'), 3, true);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE permissions (
    id serial NOT NULL,
    controller character varying(255) DEFAULT ''::character varying NOT NULL,
    "action" character varying(255) DEFAULT ''::character varying NOT NULL,
    description character varying(255)
);


ALTER TABLE public.permissions OWNER TO elaine2;

--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('permissions', 'id'), 278, true);


--
-- Name: permissions_roles; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE permissions_roles (
    permission_id integer DEFAULT 0 NOT NULL,
    role_id integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.permissions_roles OWNER TO elaine2;

--
-- Name: playlists; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE playlists (
    id serial NOT NULL,
    start_time timestamp without time zone,
    movable boolean,
    program_id integer,
    channel_id integer DEFAULT 1
);


ALTER TABLE public.playlists OWNER TO elaine2;

--
-- Name: playlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('playlists', 'id'), 339, true);


--
-- Name: program_descriptions; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE program_descriptions (
    id serial NOT NULL,
    private_description text,
    public_description text,
    title character varying(255),
    program_id integer,
    language_id integer DEFAULT 1,
    "position" integer
);


ALTER TABLE public.program_descriptions OWNER TO elaine2;

--
-- Name: program_descriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('program_descriptions', 'id'), 506, true);


--
-- Name: program_event_links; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE program_event_links (
    id serial NOT NULL,
    "position" integer,
    program_id integer,
    event_id integer
);


ALTER TABLE public.program_event_links OWNER TO elaine2;

--
-- Name: program_event_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('program_event_links', 'id'), 357, true);


--
-- Name: program_statuses; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE program_statuses (
    id serial NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.program_statuses OWNER TO elaine2;

--
-- Name: program_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('program_statuses', 'id'), 3, true);


--
-- Name: programs; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE programs (
    id serial NOT NULL,
    notes text,
    min_show integer,
    max_show integer,
    do_vod boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    preview_image_offset integer,
    preview_video_offset integer,
    owner_id integer,
    status_id integer DEFAULT 1,
    filename character varying(255),
    file_location_id integer,
    vod_group_id integer
);


ALTER TABLE public.programs OWNER TO elaine2;

--
-- Name: programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('programs', 'id'), 253, true);


--
-- Name: reference_log_entries; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE reference_log_entries (
    id serial NOT NULL,
    tape_id integer,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    channel_id integer
);


ALTER TABLE public.reference_log_entries OWNER TO elaine2;

--
-- Name: reference_log_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('reference_log_entries', 'id'), 1, false);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE roles (
    id serial NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    description character varying(255),
    omnipotent boolean DEFAULT false NOT NULL,
    system_role boolean DEFAULT false NOT NULL
);


ALTER TABLE public.roles OWNER TO elaine2;

--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('roles', 'id'), 6, true);


--
-- Name: schema_info; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE schema_info (
    version integer
);


ALTER TABLE public.schema_info OWNER TO elaine2;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE sessions (
    id serial NOT NULL,
    session_id character varying(255),
    data text,
    updated_at timestamp without time zone
);


ALTER TABLE public.sessions OWNER TO elaine2;

--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('sessions', 'id'), 1742591, true);


--
-- Name: tape_categories; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE tape_categories (
    id serial NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.tape_categories OWNER TO elaine2;

--
-- Name: tape_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('tape_categories', 'id'), 2, true);


--
-- Name: tape_event_links; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE tape_event_links (
    id serial NOT NULL,
    start_time integer,
    tape_id integer,
    event_id integer
);


ALTER TABLE public.tape_event_links OWNER TO elaine2;

--
-- Name: tape_event_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('tape_event_links', 'id'), 16, true);


--
-- Name: tape_medias; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE tape_medias (
    id serial NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.tape_medias OWNER TO elaine2;

--
-- Name: tape_medias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('tape_medias', 'id'), 5, true);


--
-- Name: tape_program_links; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE tape_program_links (
    id serial NOT NULL,
    start_time integer,
    tape_id integer,
    program_id integer
);


ALTER TABLE public.tape_program_links OWNER TO elaine2;

--
-- Name: tape_program_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('tape_program_links', 'id'), 49, true);


--
-- Name: tapes; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE tapes (
    id serial NOT NULL,
    code character varying(255),
    title text,
    length integer,
    owner_id integer,
    media_id integer DEFAULT 2,
    category_id integer DEFAULT 1
);


ALTER TABLE public.tapes OWNER TO elaine2;

--
-- Name: tapes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('tapes', 'id'), 56, true);


--
-- Name: users; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE users (
    id serial NOT NULL,
    "login" character varying(80) DEFAULT ''::character varying NOT NULL,
    salted_password character varying(40) DEFAULT ''::character varying NOT NULL,
    email character varying(60) DEFAULT ''::character varying NOT NULL,
    firstname character varying(40),
    lastname character varying(40),
    salt character varying(40) DEFAULT ''::character varying NOT NULL,
    verified integer DEFAULT 0,
    "role" character varying(40),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    logged_in_at timestamp without time zone,
    deleted integer DEFAULT 0,
    delete_after timestamp without time zone,
    security_token character varying(40),
    token_expiry timestamp without time zone
);


ALTER TABLE public.users OWNER TO elaine2;

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('users', 'id'), 55, true);


--
-- Name: users_roles; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE users_roles (
    user_id integer DEFAULT 0 NOT NULL,
    role_id integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.users_roles OWNER TO elaine2;

--
-- Name: vod_formats; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE vod_formats (
    id serial NOT NULL,
    name character varying(255),
    description text,
    vcodec character varying(255),
    acodec character varying(255),
    container character varying(255),
    vbitrate integer,
    abitrate integer,
    width integer,
    height integer,
    framerate integer
);


ALTER TABLE public.vod_formats OWNER TO elaine2;

--
-- Name: vod_formats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('vod_formats', 'id'), 10, true);


--
-- Name: vod_group_format_links; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE vod_group_format_links (
    id serial NOT NULL,
    vod_group_id integer,
    vod_format_id integer
);


ALTER TABLE public.vod_group_format_links OWNER TO elaine2;

--
-- Name: vod_group_format_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('vod_group_format_links', 'id'), 10, true);


--
-- Name: vod_groups; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE vod_groups (
    id serial NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.vod_groups OWNER TO elaine2;

--
-- Name: vod_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('vod_groups', 'id'), 3, true);


--
-- Name: vods; Type: TABLE; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE TABLE vods (
    id serial NOT NULL,
    filename character varying(255),
    file_location_id integer,
    length integer,
    filesize integer,
    vod_format_id integer,
    completed boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    program_id integer
);


ALTER TABLE public.vods OWNER TO elaine2;

--
-- Name: vods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('vods', 'id'), 1095, true);


--
-- Data for Name: broadcast_logs; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY broadcast_logs (id, start_time, program_id, channel_id) FROM stdin;
\.
copy broadcast_logs (id, start_time, program_id, channel_id)  from '$$PATH$$/1796.dat' ;
--
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY channels (id, name, description) FROM stdin;
\.
copy channels (id, name, description)  from '$$PATH$$/1784.dat' ;
--
-- Data for Name: engine_schema_info; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY engine_schema_info (engine_name, version) FROM stdin;
\.
copy engine_schema_info (engine_name, version)  from '$$PATH$$/1772.dat' ;
--
-- Data for Name: event_types; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY event_types (id, name, description) FROM stdin;
\.
copy event_types (id, name, description)  from '$$PATH$$/1783.dat' ;
--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY events (id, title, script, location_id, event_type_id, notes, length, quarantine, created_at, updated_at, filename, file_location_id) FROM stdin;
\.
copy events (id, title, script, location_id, event_type_id, notes, length, quarantine, created_at, updated_at, filename, file_location_id)  from '$$PATH$$/1788.dat' ;
--
-- Data for Name: file_locations; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY file_locations (id, name, description, url, checker_url) FROM stdin;
\.
copy file_locations (id, name, description, url, checker_url)  from '$$PATH$$/1787.dat' ;
--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY languages (id, name, code, compulsory) FROM stdin;
\.
copy languages (id, name, code, compulsory)  from '$$PATH$$/1786.dat' ;
--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY locations (id, name, description) FROM stdin;
\.
copy locations (id, name, description)  from '$$PATH$$/1779.dat' ;
--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY people (id, name, title, organization, phone, email) FROM stdin;
\.
copy people (id, name, title, organization, phone, email)  from '$$PATH$$/1797.dat' ;
--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY permissions (id, controller, "action", description) FROM stdin;
\.
copy permissions (id, controller, "action", description)  from '$$PATH$$/1774.dat' ;
--
-- Data for Name: permissions_roles; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY permissions_roles (permission_id, role_id) FROM stdin;
\.
copy permissions_roles (permission_id, role_id)  from '$$PATH$$/1775.dat' ;
--
-- Data for Name: playlists; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY playlists (id, start_time, movable, program_id, channel_id) FROM stdin;
\.
copy playlists (id, start_time, movable, program_id, channel_id)  from '$$PATH$$/1791.dat' ;
--
-- Data for Name: program_descriptions; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY program_descriptions (id, private_description, public_description, title, program_id, language_id, "position") FROM stdin;
\.
copy program_descriptions (id, private_description, public_description, title, program_id, language_id, "position")  from '$$PATH$$/1792.dat' ;
--
-- Data for Name: program_event_links; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY program_event_links (id, "position", program_id, event_id) FROM stdin;
\.
copy program_event_links (id, "position", program_id, event_id)  from '$$PATH$$/1799.dat' ;
--
-- Data for Name: program_statuses; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY program_statuses (id, name, description) FROM stdin;
\.
copy program_statuses (id, name, description)  from '$$PATH$$/1782.dat' ;
--
-- Data for Name: programs; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY programs (id, notes, min_show, max_show, do_vod, created_at, updated_at, preview_image_offset, preview_video_offset, owner_id, status_id, filename, file_location_id, vod_group_id) FROM stdin;
\.
copy programs (id, notes, min_show, max_show, do_vod, created_at, updated_at, preview_image_offset, preview_video_offset, owner_id, status_id, filename, file_location_id, vod_group_id)  from '$$PATH$$/1789.dat' ;
--
-- Data for Name: reference_log_entries; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY reference_log_entries (id, tape_id, start_time, end_time, channel_id) FROM stdin;
\.
copy reference_log_entries (id, tape_id, start_time, end_time, channel_id)  from '$$PATH$$/1801.dat' ;
--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY roles (id, name, description, omnipotent, system_role) FROM stdin;
\.
copy roles (id, name, description, omnipotent, system_role)  from '$$PATH$$/1777.dat' ;
--
-- Data for Name: schema_info; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY schema_info (version) FROM stdin;
\.
copy schema_info (version)  from '$$PATH$$/1771.dat' ;
--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY sessions (id, session_id, data, updated_at) FROM stdin;
\.
copy sessions (id, session_id, data, updated_at)  from '$$PATH$$/1798.dat' ;
--
-- Data for Name: tape_categories; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY tape_categories (id, name, description) FROM stdin;
\.
copy tape_categories (id, name, description)  from '$$PATH$$/1785.dat' ;
--
-- Data for Name: tape_event_links; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY tape_event_links (id, start_time, tape_id, event_id) FROM stdin;
\.
copy tape_event_links (id, start_time, tape_id, event_id)  from '$$PATH$$/1793.dat' ;
--
-- Data for Name: tape_medias; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY tape_medias (id, name, description) FROM stdin;
\.
copy tape_medias (id, name, description)  from '$$PATH$$/1778.dat' ;
--
-- Data for Name: tape_program_links; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY tape_program_links (id, start_time, tape_id, program_id) FROM stdin;
\.
copy tape_program_links (id, start_time, tape_id, program_id)  from '$$PATH$$/1794.dat' ;
--
-- Data for Name: tapes; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY tapes (id, code, title, length, owner_id, media_id, category_id) FROM stdin;
\.
copy tapes (id, code, title, length, owner_id, media_id, category_id)  from '$$PATH$$/1790.dat' ;
--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY users (id, "login", salted_password, email, firstname, lastname, salt, verified, "role", created_at, updated_at, logged_in_at, deleted, delete_after, security_token, token_expiry) FROM stdin;
\.
copy users (id, "login", salted_password, email, firstname, lastname, salt, verified, "role", created_at, updated_at, logged_in_at, deleted, delete_after, security_token, token_expiry)  from '$$PATH$$/1773.dat' ;
--
-- Data for Name: users_roles; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY users_roles (user_id, role_id) FROM stdin;
\.
copy users_roles (user_id, role_id)  from '$$PATH$$/1776.dat' ;
--
-- Data for Name: vod_formats; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY vod_formats (id, name, description, vcodec, acodec, container, vbitrate, abitrate, width, height, framerate) FROM stdin;
\.
copy vod_formats (id, name, description, vcodec, acodec, container, vbitrate, abitrate, width, height, framerate)  from '$$PATH$$/1781.dat' ;
--
-- Data for Name: vod_group_format_links; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY vod_group_format_links (id, vod_group_id, vod_format_id) FROM stdin;
\.
copy vod_group_format_links (id, vod_group_id, vod_format_id)  from '$$PATH$$/1800.dat' ;
--
-- Data for Name: vod_groups; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY vod_groups (id, name, description) FROM stdin;
\.
copy vod_groups (id, name, description)  from '$$PATH$$/1780.dat' ;
--
-- Data for Name: vods; Type: TABLE DATA; Schema: public; Owner: elaine2
--

COPY vods (id, filename, file_location_id, length, filesize, vod_format_id, completed, created_at, updated_at, program_id) FROM stdin;
\.
copy vods (id, filename, file_location_id, length, filesize, vod_format_id, completed, created_at, updated_at, program_id)  from '$$PATH$$/1795.dat' ;
--
-- Name: broadcast_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY broadcast_logs
    ADD CONSTRAINT broadcast_logs_pkey PRIMARY KEY (id);


--
-- Name: channels_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);


--
-- Name: event_types_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY event_types
    ADD CONSTRAINT event_types_pkey PRIMARY KEY (id);


--
-- Name: events_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: file_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY file_locations
    ADD CONSTRAINT file_locations_pkey PRIMARY KEY (id);


--
-- Name: languages_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (id);


--
-- Name: locations_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: people_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY playlists
    ADD CONSTRAINT playlists_pkey PRIMARY KEY (id);


--
-- Name: program_descriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY program_descriptions
    ADD CONSTRAINT program_descriptions_pkey PRIMARY KEY (id);


--
-- Name: program_event_links_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY program_event_links
    ADD CONSTRAINT program_event_links_pkey PRIMARY KEY (id);


--
-- Name: program_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY program_statuses
    ADD CONSTRAINT program_statuses_pkey PRIMARY KEY (id);


--
-- Name: programs_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY programs
    ADD CONSTRAINT programs_pkey PRIMARY KEY (id);


--
-- Name: reference_log_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY reference_log_entries
    ADD CONSTRAINT reference_log_entries_pkey PRIMARY KEY (id);


--
-- Name: roles_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: tape_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY tape_categories
    ADD CONSTRAINT tape_categories_pkey PRIMARY KEY (id);


--
-- Name: tape_event_links_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY tape_event_links
    ADD CONSTRAINT tape_event_links_pkey PRIMARY KEY (id);


--
-- Name: tape_medias_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY tape_medias
    ADD CONSTRAINT tape_medias_pkey PRIMARY KEY (id);


--
-- Name: tape_program_links_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY tape_program_links
    ADD CONSTRAINT tape_program_links_pkey PRIMARY KEY (id);


--
-- Name: tapes_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY tapes
    ADD CONSTRAINT tapes_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vod_formats_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY vod_formats
    ADD CONSTRAINT vod_formats_pkey PRIMARY KEY (id);


--
-- Name: vod_group_format_links_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY vod_group_format_links
    ADD CONSTRAINT vod_group_format_links_pkey PRIMARY KEY (id);


--
-- Name: vod_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY vod_groups
    ADD CONSTRAINT vod_groups_pkey PRIMARY KEY (id);


--
-- Name: vods_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2; Tablespace: 
--

ALTER TABLE ONLY vods
    ADD CONSTRAINT vods_pkey PRIMARY KEY (id);


--
-- Name: sessions_session_id_index; Type: INDEX; Schema: public; Owner: elaine2; Tablespace: 
--

CREATE INDEX sessions_session_id_index ON sessions USING btree (session_id);


--
-- Name: category; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tapes
    ADD CONSTRAINT category FOREIGN KEY (category_id) REFERENCES tape_categories(id);


--
-- Name: channel; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY playlists
    ADD CONSTRAINT channel FOREIGN KEY (channel_id) REFERENCES channels(id);


--
-- Name: channel; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY broadcast_logs
    ADD CONSTRAINT channel FOREIGN KEY (channel_id) REFERENCES channels(id);


--
-- Name: channel; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY reference_log_entries
    ADD CONSTRAINT channel FOREIGN KEY (channel_id) REFERENCES channels(id);


--
-- Name: event; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_event_links
    ADD CONSTRAINT event FOREIGN KEY (event_id) REFERENCES events(id);


--
-- Name: event; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY program_event_links
    ADD CONSTRAINT event FOREIGN KEY (event_id) REFERENCES events(id);


--
-- Name: event_type; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY events
    ADD CONSTRAINT event_type FOREIGN KEY (event_type_id) REFERENCES event_types(id);


--
-- Name: file_location; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY events
    ADD CONSTRAINT file_location FOREIGN KEY (file_location_id) REFERENCES file_locations(id);


--
-- Name: file_location; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY programs
    ADD CONSTRAINT file_location FOREIGN KEY (file_location_id) REFERENCES file_locations(id);


--
-- Name: file_location; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vods
    ADD CONSTRAINT file_location FOREIGN KEY (file_location_id) REFERENCES file_locations(id);


--
-- Name: language; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY program_descriptions
    ADD CONSTRAINT "language" FOREIGN KEY (language_id) REFERENCES languages(id);


--
-- Name: location; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY events
    ADD CONSTRAINT "location" FOREIGN KEY (location_id) REFERENCES locations(id);


--
-- Name: media; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tapes
    ADD CONSTRAINT media FOREIGN KEY (media_id) REFERENCES tape_medias(id);


--
-- Name: owner; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY programs
    ADD CONSTRAINT "owner" FOREIGN KEY (owner_id) REFERENCES users(id);


--
-- Name: owner; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tapes
    ADD CONSTRAINT "owner" FOREIGN KEY (owner_id) REFERENCES users(id);


--
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY playlists
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY program_descriptions
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_program_links
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vods
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY broadcast_logs
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY program_event_links
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- Name: status; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY programs
    ADD CONSTRAINT status FOREIGN KEY (status_id) REFERENCES program_statuses(id);


--
-- Name: tape; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_event_links
    ADD CONSTRAINT tape FOREIGN KEY (tape_id) REFERENCES tapes(id);


--
-- Name: tape; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_program_links
    ADD CONSTRAINT tape FOREIGN KEY (tape_id) REFERENCES tapes(id);


--
-- Name: tape; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY reference_log_entries
    ADD CONSTRAINT tape FOREIGN KEY (tape_id) REFERENCES tapes(id);


--
-- Name: vod_format; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vods
    ADD CONSTRAINT vod_format FOREIGN KEY (vod_format_id) REFERENCES vod_formats(id);


--
-- Name: vod_format; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vod_group_format_links
    ADD CONSTRAINT vod_format FOREIGN KEY (vod_format_id) REFERENCES vod_formats(id);


--
-- Name: vod_group; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY programs
    ADD CONSTRAINT vod_group FOREIGN KEY (vod_group_id) REFERENCES vod_groups(id);


--
-- Name: vod_group; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vod_group_format_links
    ADD CONSTRAINT vod_group FOREIGN KEY (vod_group_id) REFERENCES vod_groups(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

