create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'LATIN1';
SET check_function_bodies = false;

SET SESSION AUTHORIZATION 'postgres';

SET SESSION AUTHORIZATION 'elaine2';

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.reference_log_entries DROP CONSTRAINT channel;
ALTER TABLE ONLY public.reference_log_entries DROP CONSTRAINT tape;
ALTER TABLE ONLY public.vod_group_format_links DROP CONSTRAINT vod_format;
ALTER TABLE ONLY public.vod_group_format_links DROP CONSTRAINT vod_group;
ALTER TABLE ONLY public.program_event_links DROP CONSTRAINT event;
ALTER TABLE ONLY public.program_event_links DROP CONSTRAINT program;
ALTER TABLE ONLY public.broadcast_logs DROP CONSTRAINT channel;
ALTER TABLE ONLY public.broadcast_logs DROP CONSTRAINT program;
ALTER TABLE ONLY public.vods DROP CONSTRAINT vod_format;
ALTER TABLE ONLY public.vods DROP CONSTRAINT file_location;
ALTER TABLE ONLY public.vods DROP CONSTRAINT program;
ALTER TABLE ONLY public.tape_program_links DROP CONSTRAINT program;
ALTER TABLE ONLY public.tape_program_links DROP CONSTRAINT tape;
ALTER TABLE ONLY public.tape_event_links DROP CONSTRAINT event;
ALTER TABLE ONLY public.tape_event_links DROP CONSTRAINT tape;
ALTER TABLE ONLY public.program_descriptions DROP CONSTRAINT "language";
ALTER TABLE ONLY public.program_descriptions DROP CONSTRAINT program;
ALTER TABLE ONLY public.playlists DROP CONSTRAINT channel;
ALTER TABLE ONLY public.playlists DROP CONSTRAINT program;
ALTER TABLE ONLY public.tapes DROP CONSTRAINT "owner";
ALTER TABLE ONLY public.tapes DROP CONSTRAINT media;
ALTER TABLE ONLY public.tapes DROP CONSTRAINT category;
ALTER TABLE ONLY public.programs DROP CONSTRAINT vod_group;
ALTER TABLE ONLY public.programs DROP CONSTRAINT file_location;
ALTER TABLE ONLY public.programs DROP CONSTRAINT status;
ALTER TABLE ONLY public.programs DROP CONSTRAINT "owner";
ALTER TABLE ONLY public.events DROP CONSTRAINT file_location;
ALTER TABLE ONLY public.events DROP CONSTRAINT event_type;
ALTER TABLE ONLY public.events DROP CONSTRAINT "location";
ALTER TABLE ONLY public.reference_log_entries DROP CONSTRAINT reference_log_entries_pkey;
ALTER TABLE ONLY public.vod_group_format_links DROP CONSTRAINT vod_group_format_links_pkey;
ALTER TABLE ONLY public.program_event_links DROP CONSTRAINT program_event_links_pkey;
ALTER TABLE ONLY public.sessions DROP CONSTRAINT sessions_pkey;
ALTER TABLE ONLY public.people DROP CONSTRAINT people_pkey;
ALTER TABLE ONLY public.broadcast_logs DROP CONSTRAINT broadcast_logs_pkey;
ALTER TABLE ONLY public.vods DROP CONSTRAINT vods_pkey;
ALTER TABLE ONLY public.tape_program_links DROP CONSTRAINT tape_program_links_pkey;
ALTER TABLE ONLY public.tape_event_links DROP CONSTRAINT tape_event_links_pkey;
ALTER TABLE ONLY public.program_descriptions DROP CONSTRAINT program_descriptions_pkey;
ALTER TABLE ONLY public.playlists DROP CONSTRAINT playlists_pkey;
ALTER TABLE ONLY public.tapes DROP CONSTRAINT tapes_pkey;
ALTER TABLE ONLY public.programs DROP CONSTRAINT programs_pkey;
ALTER TABLE ONLY public.events DROP CONSTRAINT events_pkey;
ALTER TABLE ONLY public.file_locations DROP CONSTRAINT file_locations_pkey;
ALTER TABLE ONLY public.languages DROP CONSTRAINT languages_pkey;
ALTER TABLE ONLY public.tape_categories DROP CONSTRAINT tape_categories_pkey;
ALTER TABLE ONLY public.channels DROP CONSTRAINT channels_pkey;
ALTER TABLE ONLY public.event_types DROP CONSTRAINT event_types_pkey;
ALTER TABLE ONLY public.program_statuses DROP CONSTRAINT program_statuses_pkey;
ALTER TABLE ONLY public.vod_formats DROP CONSTRAINT vod_formats_pkey;
ALTER TABLE ONLY public.vod_groups DROP CONSTRAINT vod_groups_pkey;
ALTER TABLE ONLY public.locations DROP CONSTRAINT locations_pkey;
ALTER TABLE ONLY public.tape_medias DROP CONSTRAINT tape_medias_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.permissions DROP CONSTRAINT permissions_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
DROP INDEX public.sessions_session_id_index;
DROP TABLE public.reference_log_entries;
DROP TABLE public.vod_group_format_links;
DROP TABLE public.program_event_links;
DROP TABLE public.sessions;
DROP TABLE public.people;
DROP TABLE public.broadcast_logs;
DROP TABLE public.vods;
DROP TABLE public.tape_program_links;
DROP TABLE public.tape_event_links;
DROP TABLE public.program_descriptions;
DROP TABLE public.playlists;
DROP TABLE public.tapes;
DROP TABLE public.programs;
DROP TABLE public.events;
DROP TABLE public.file_locations;
DROP TABLE public.languages;
DROP TABLE public.tape_categories;
DROP TABLE public.channels;
DROP TABLE public.event_types;
DROP TABLE public.program_statuses;
DROP TABLE public.vod_formats;
DROP TABLE public.vod_groups;
DROP TABLE public.locations;
DROP TABLE public.tape_medias;
DROP TABLE public.roles;
DROP TABLE public.users_roles;
DROP TABLE public.permissions_roles;
DROP TABLE public.permissions;
DROP TABLE public.users;
DROP TABLE public.engine_schema_info;
DROP TABLE public.schema_info;
SET SESSION AUTHORIZATION 'postgres';

--
-- TOC entry 4 (OID 2200)
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


SET SESSION AUTHORIZATION 'elaine2';

--
-- TOC entry 5 (OID 19007)
-- Name: schema_info; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE schema_info (
    "version" integer
);


--
-- TOC entry 6 (OID 19009)
-- Name: engine_schema_info; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE engine_schema_info (
    engine_name character varying(255),
    "version" integer
);


--
-- TOC entry 7 (OID 19013)
-- Name: users; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE users (
    id serial NOT NULL,
    login character varying(80) DEFAULT ''::character varying NOT NULL,
    salted_password character varying(40) DEFAULT ''::character varying NOT NULL,
    email character varying(60) DEFAULT ''::character varying NOT NULL,
    firstname character varying(40),
    lastname character varying(40),
    salt character varying(40) DEFAULT ''::character varying NOT NULL,
    verified integer DEFAULT 0,
    role character varying(40),
    security_token character varying(40),
    token_expiry timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    logged_in_at timestamp without time zone,
    deleted integer DEFAULT 0,
    delete_after timestamp without time zone
);


--
-- TOC entry 8 (OID 19024)
-- Name: permissions; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE permissions (
    id serial NOT NULL,
    controller character varying(255) DEFAULT ''::character varying NOT NULL,
    "action" character varying(255) DEFAULT ''::character varying NOT NULL,
    description character varying(255)
);


--
-- TOC entry 9 (OID 19029)
-- Name: permissions_roles; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE permissions_roles (
    permission_id integer DEFAULT 0 NOT NULL,
    role_id integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 10 (OID 19033)
-- Name: users_roles; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE users_roles (
    user_id integer DEFAULT 0 NOT NULL,
    role_id integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 11 (OID 19039)
-- Name: roles; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE roles (
    id serial NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    description character varying(255),
    omnipotent boolean DEFAULT false NOT NULL,
    system_role boolean DEFAULT false NOT NULL
);


--
-- TOC entry 12 (OID 19047)
-- Name: tape_medias; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE tape_medias (
    id serial NOT NULL,
    name character varying(255),
    description text
);


--
-- TOC entry 13 (OID 19055)
-- Name: locations; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE locations (
    id serial NOT NULL,
    name character varying(255),
    description text
);


--
-- TOC entry 14 (OID 19063)
-- Name: vod_groups; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE vod_groups (
    id serial NOT NULL,
    name character varying(255),
    description text
);


--
-- TOC entry 15 (OID 19071)
-- Name: vod_formats; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE vod_formats (
    id serial NOT NULL,
    name character varying(255),
    description text,
    vcodec character varying(255),
    acodec character varying(255),
    container character varying(255),
    vbitrate integer,
    abitrate integer,
    width integer,
    height integer,
    framerate integer
);


--
-- TOC entry 16 (OID 19079)
-- Name: program_statuses; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE program_statuses (
    id serial NOT NULL,
    name character varying(255),
    description text
);


--
-- TOC entry 17 (OID 19087)
-- Name: event_types; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE event_types (
    id serial NOT NULL,
    name character varying(255),
    description text
);


--
-- TOC entry 18 (OID 19095)
-- Name: channels; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE channels (
    id serial NOT NULL,
    name character varying(255),
    description text
);


--
-- TOC entry 19 (OID 19103)
-- Name: tape_categories; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE tape_categories (
    id serial NOT NULL,
    name character varying(255),
    description text
);


--
-- TOC entry 20 (OID 19111)
-- Name: languages; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE languages (
    id serial NOT NULL,
    name character varying(255),
    code character varying(255),
    compulsory boolean DEFAULT true
);


--
-- TOC entry 21 (OID 19117)
-- Name: file_locations; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE file_locations (
    id serial NOT NULL,
    name character varying(255),
    description text,
    url character varying(255),
    checker_url character varying(255)
);


--
-- TOC entry 22 (OID 19125)
-- Name: events; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE events (
    id serial NOT NULL,
    title character varying(255),
    script text,
    location_id integer DEFAULT 1,
    event_type_id integer,
    notes text,
    length integer,
    quarantine timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    filename character varying(255),
    file_location_id integer
);


--
-- TOC entry 23 (OID 19134)
-- Name: programs; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE programs (
    id serial NOT NULL,
    notes text,
    min_show integer,
    max_show integer,
    do_vod boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    preview_image_offset integer,
    preview_video_offset integer,
    owner_id integer,
    status_id integer DEFAULT 1,
    filename character varying(255),
    file_location_id integer,
    vod_group_id integer
);


--
-- TOC entry 24 (OID 19143)
-- Name: tapes; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE tapes (
    id serial NOT NULL,
    code character varying(255),
    title text,
    length integer,
    owner_id integer,
    media_id integer DEFAULT 2,
    category_id integer DEFAULT 1
);


--
-- TOC entry 25 (OID 19153)
-- Name: playlists; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE playlists (
    id serial NOT NULL,
    start_time timestamp without time zone,
    movable boolean,
    program_id integer,
    channel_id integer DEFAULT 1
);


--
-- TOC entry 26 (OID 19159)
-- Name: program_descriptions; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE program_descriptions (
    id serial NOT NULL,
    private_description text,
    public_description text,
    title character varying(255),
    program_id integer,
    language_id integer DEFAULT 1,
    "position" integer
);


--
-- TOC entry 27 (OID 19168)
-- Name: tape_event_links; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE tape_event_links (
    id serial NOT NULL,
    start_time integer,
    tape_id integer,
    event_id integer
);


--
-- TOC entry 28 (OID 19173)
-- Name: tape_program_links; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE tape_program_links (
    id serial NOT NULL,
    start_time integer,
    tape_id integer,
    program_id integer
);


--
-- TOC entry 29 (OID 19178)
-- Name: vods; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE vods (
    id serial NOT NULL,
    filename character varying(255),
    file_location_id integer,
    length integer,
    filesize integer,
    vod_format_id integer,
    completed boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    program_id integer
);


--
-- TOC entry 30 (OID 19183)
-- Name: broadcast_logs; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE broadcast_logs (
    id serial NOT NULL,
    start_time timestamp without time zone,
    program_id integer,
    channel_id integer DEFAULT 1
);


--
-- TOC entry 31 (OID 19189)
-- Name: people; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE people (
    id serial NOT NULL,
    name character varying(255),
    title character varying(255),
    organization character varying(255),
    phone character varying(255),
    email character varying(255)
);


--
-- TOC entry 32 (OID 19194)
-- Name: sessions; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE sessions (
    id serial NOT NULL,
    session_id character varying(255),
    data text,
    updated_at timestamp without time zone
);


--
-- TOC entry 33 (OID 19202)
-- Name: program_event_links; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE program_event_links (
    id serial NOT NULL,
    "position" integer,
    program_id integer,
    event_id integer
);


--
-- TOC entry 34 (OID 19207)
-- Name: vod_group_format_links; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE vod_group_format_links (
    id serial NOT NULL,
    vod_group_id integer,
    vod_format_id integer
);


--
-- TOC entry 35 (OID 19212)
-- Name: reference_log_entries; Type: TABLE; Schema: public; Owner: elaine2
--

CREATE TABLE reference_log_entries (
    id serial NOT NULL,
    tape_id integer,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    channel_id integer
);


--
-- Data for TOC entry 91 (OID 19007)
-- Name: schema_info; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 91.dat
--

COPY schema_info ("version") FROM stdin;
\.
copy schema_info ("version")  from '$$PATH$$/91.dat' ;
--
-- Data for TOC entry 92 (OID 19009)
-- Name: engine_schema_info; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 92.dat
--

COPY engine_schema_info (engine_name, "version") FROM stdin;
\.
copy engine_schema_info (engine_name, "version")  from '$$PATH$$/92.dat' ;
--
-- Data for TOC entry 93 (OID 19013)
-- Name: users; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 93.dat
--

COPY users (id, login, salted_password, email, firstname, lastname, salt, verified, role, security_token, token_expiry, created_at, updated_at, logged_in_at, deleted, delete_after) FROM stdin;
\.
copy users (id, login, salted_password, email, firstname, lastname, salt, verified, role, security_token, token_expiry, created_at, updated_at, logged_in_at, deleted, delete_after)  from '$$PATH$$/93.dat' ;
--
-- Data for TOC entry 94 (OID 19024)
-- Name: permissions; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 94.dat
--

COPY permissions (id, controller, "action", description) FROM stdin;
\.
copy permissions (id, controller, "action", description)  from '$$PATH$$/94.dat' ;
--
-- Data for TOC entry 95 (OID 19029)
-- Name: permissions_roles; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 95.dat
--

COPY permissions_roles (permission_id, role_id) FROM stdin;
\.
copy permissions_roles (permission_id, role_id)  from '$$PATH$$/95.dat' ;
--
-- Data for TOC entry 96 (OID 19033)
-- Name: users_roles; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 96.dat
--

COPY users_roles (user_id, role_id) FROM stdin;
\.
copy users_roles (user_id, role_id)  from '$$PATH$$/96.dat' ;
--
-- Data for TOC entry 97 (OID 19039)
-- Name: roles; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 97.dat
--

COPY roles (id, name, description, omnipotent, system_role) FROM stdin;
\.
copy roles (id, name, description, omnipotent, system_role)  from '$$PATH$$/97.dat' ;
--
-- Data for TOC entry 98 (OID 19047)
-- Name: tape_medias; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 98.dat
--

COPY tape_medias (id, name, description) FROM stdin;
\.
copy tape_medias (id, name, description)  from '$$PATH$$/98.dat' ;
--
-- Data for TOC entry 99 (OID 19055)
-- Name: locations; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 99.dat
--

COPY locations (id, name, description) FROM stdin;
\.
copy locations (id, name, description)  from '$$PATH$$/99.dat' ;
--
-- Data for TOC entry 100 (OID 19063)
-- Name: vod_groups; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 100.dat
--

COPY vod_groups (id, name, description) FROM stdin;
\.
copy vod_groups (id, name, description)  from '$$PATH$$/100.dat' ;
--
-- Data for TOC entry 101 (OID 19071)
-- Name: vod_formats; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 101.dat
--

COPY vod_formats (id, name, description, vcodec, acodec, container, vbitrate, abitrate, width, height, framerate) FROM stdin;
\.
copy vod_formats (id, name, description, vcodec, acodec, container, vbitrate, abitrate, width, height, framerate)  from '$$PATH$$/101.dat' ;
--
-- Data for TOC entry 102 (OID 19079)
-- Name: program_statuses; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 102.dat
--

COPY program_statuses (id, name, description) FROM stdin;
\.
copy program_statuses (id, name, description)  from '$$PATH$$/102.dat' ;
--
-- Data for TOC entry 103 (OID 19087)
-- Name: event_types; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 103.dat
--

COPY event_types (id, name, description) FROM stdin;
\.
copy event_types (id, name, description)  from '$$PATH$$/103.dat' ;
--
-- Data for TOC entry 104 (OID 19095)
-- Name: channels; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 104.dat
--

COPY channels (id, name, description) FROM stdin;
\.
copy channels (id, name, description)  from '$$PATH$$/104.dat' ;
--
-- Data for TOC entry 105 (OID 19103)
-- Name: tape_categories; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 105.dat
--

COPY tape_categories (id, name, description) FROM stdin;
\.
copy tape_categories (id, name, description)  from '$$PATH$$/105.dat' ;
--
-- Data for TOC entry 106 (OID 19111)
-- Name: languages; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 106.dat
--

COPY languages (id, name, code, compulsory) FROM stdin;
\.
copy languages (id, name, code, compulsory)  from '$$PATH$$/106.dat' ;
--
-- Data for TOC entry 107 (OID 19117)
-- Name: file_locations; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 107.dat
--

COPY file_locations (id, name, description, url, checker_url) FROM stdin;
\.
copy file_locations (id, name, description, url, checker_url)  from '$$PATH$$/107.dat' ;
--
-- Data for TOC entry 108 (OID 19125)
-- Name: events; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 108.dat
--

COPY events (id, title, script, location_id, event_type_id, notes, length, quarantine, created_at, updated_at, filename, file_location_id) FROM stdin;
\.
copy events (id, title, script, location_id, event_type_id, notes, length, quarantine, created_at, updated_at, filename, file_location_id)  from '$$PATH$$/108.dat' ;
--
-- Data for TOC entry 109 (OID 19134)
-- Name: programs; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 109.dat
--

COPY programs (id, notes, min_show, max_show, do_vod, created_at, updated_at, preview_image_offset, preview_video_offset, owner_id, status_id, filename, file_location_id, vod_group_id) FROM stdin;
\.
copy programs (id, notes, min_show, max_show, do_vod, created_at, updated_at, preview_image_offset, preview_video_offset, owner_id, status_id, filename, file_location_id, vod_group_id)  from '$$PATH$$/109.dat' ;
--
-- Data for TOC entry 110 (OID 19143)
-- Name: tapes; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 110.dat
--

COPY tapes (id, code, title, length, owner_id, media_id, category_id) FROM stdin;
\.
copy tapes (id, code, title, length, owner_id, media_id, category_id)  from '$$PATH$$/110.dat' ;
--
-- Data for TOC entry 111 (OID 19153)
-- Name: playlists; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 111.dat
--

COPY playlists (id, start_time, movable, program_id, channel_id) FROM stdin;
\.
copy playlists (id, start_time, movable, program_id, channel_id)  from '$$PATH$$/111.dat' ;
--
-- Data for TOC entry 112 (OID 19159)
-- Name: program_descriptions; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 112.dat
--

COPY program_descriptions (id, private_description, public_description, title, program_id, language_id, "position") FROM stdin;
\.
copy program_descriptions (id, private_description, public_description, title, program_id, language_id, "position")  from '$$PATH$$/112.dat' ;
--
-- Data for TOC entry 113 (OID 19168)
-- Name: tape_event_links; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 113.dat
--

COPY tape_event_links (id, start_time, tape_id, event_id) FROM stdin;
\.
copy tape_event_links (id, start_time, tape_id, event_id)  from '$$PATH$$/113.dat' ;
--
-- Data for TOC entry 114 (OID 19173)
-- Name: tape_program_links; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 114.dat
--

COPY tape_program_links (id, start_time, tape_id, program_id) FROM stdin;
\.
copy tape_program_links (id, start_time, tape_id, program_id)  from '$$PATH$$/114.dat' ;
--
-- Data for TOC entry 115 (OID 19178)
-- Name: vods; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 115.dat
--

COPY vods (id, filename, file_location_id, length, filesize, vod_format_id, completed, created_at, updated_at, program_id) FROM stdin;
\.
copy vods (id, filename, file_location_id, length, filesize, vod_format_id, completed, created_at, updated_at, program_id)  from '$$PATH$$/115.dat' ;
--
-- Data for TOC entry 116 (OID 19183)
-- Name: broadcast_logs; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 116.dat
--

COPY broadcast_logs (id, start_time, program_id, channel_id) FROM stdin;
\.
copy broadcast_logs (id, start_time, program_id, channel_id)  from '$$PATH$$/116.dat' ;
--
-- Data for TOC entry 117 (OID 19189)
-- Name: people; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 117.dat
--

COPY people (id, name, title, organization, phone, email) FROM stdin;
\.
copy people (id, name, title, organization, phone, email)  from '$$PATH$$/117.dat' ;
--
-- Data for TOC entry 118 (OID 19194)
-- Name: sessions; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 118.dat
--

COPY sessions (id, session_id, data, updated_at) FROM stdin;
\.
copy sessions (id, session_id, data, updated_at)  from '$$PATH$$/118.dat' ;
--
-- Data for TOC entry 119 (OID 19202)
-- Name: program_event_links; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 119.dat
--

COPY program_event_links (id, "position", program_id, event_id) FROM stdin;
\.
copy program_event_links (id, "position", program_id, event_id)  from '$$PATH$$/119.dat' ;
--
-- Data for TOC entry 120 (OID 19207)
-- Name: vod_group_format_links; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 120.dat
--

COPY vod_group_format_links (id, vod_group_id, vod_format_id) FROM stdin;
\.
copy vod_group_format_links (id, vod_group_id, vod_format_id)  from '$$PATH$$/120.dat' ;
--
-- Data for TOC entry 121 (OID 19212)
-- Name: reference_log_entries; Type: TABLE DATA; Schema: public; Owner: elaine2
-- File: 121.dat
--

COPY reference_log_entries (id, tape_id, start_time, end_time, channel_id) FROM stdin;
\.
copy reference_log_entries (id, tape_id, start_time, end_time, channel_id)  from '$$PATH$$/121.dat' ;
--
-- TOC entry 87 (OID 20104)
-- Name: sessions_session_id_index; Type: INDEX; Schema: public; Owner: elaine2
--

CREATE INDEX sessions_session_id_index ON sessions USING btree (session_id);


--
-- TOC entry 63 (OID 20105)
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 64 (OID 20107)
-- Name: permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 65 (OID 20109)
-- Name: roles_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 66 (OID 20111)
-- Name: tape_medias_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_medias
    ADD CONSTRAINT tape_medias_pkey PRIMARY KEY (id);


--
-- TOC entry 67 (OID 20113)
-- Name: locations_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- TOC entry 68 (OID 20115)
-- Name: vod_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vod_groups
    ADD CONSTRAINT vod_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 69 (OID 20117)
-- Name: vod_formats_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vod_formats
    ADD CONSTRAINT vod_formats_pkey PRIMARY KEY (id);


--
-- TOC entry 70 (OID 20119)
-- Name: program_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY program_statuses
    ADD CONSTRAINT program_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 71 (OID 20121)
-- Name: event_types_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY event_types
    ADD CONSTRAINT event_types_pkey PRIMARY KEY (id);


--
-- TOC entry 72 (OID 20123)
-- Name: channels_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);


--
-- TOC entry 73 (OID 20125)
-- Name: tape_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_categories
    ADD CONSTRAINT tape_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 74 (OID 20127)
-- Name: languages_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (id);


--
-- TOC entry 75 (OID 20129)
-- Name: file_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY file_locations
    ADD CONSTRAINT file_locations_pkey PRIMARY KEY (id);


--
-- TOC entry 76 (OID 20131)
-- Name: events_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- TOC entry 77 (OID 20145)
-- Name: programs_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY programs
    ADD CONSTRAINT programs_pkey PRIMARY KEY (id);


--
-- TOC entry 78 (OID 20163)
-- Name: tapes_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tapes
    ADD CONSTRAINT tapes_pkey PRIMARY KEY (id);


--
-- TOC entry 79 (OID 20177)
-- Name: playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY playlists
    ADD CONSTRAINT playlists_pkey PRIMARY KEY (id);


--
-- TOC entry 80 (OID 20187)
-- Name: program_descriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY program_descriptions
    ADD CONSTRAINT program_descriptions_pkey PRIMARY KEY (id);


--
-- TOC entry 81 (OID 20197)
-- Name: tape_event_links_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_event_links
    ADD CONSTRAINT tape_event_links_pkey PRIMARY KEY (id);


--
-- TOC entry 82 (OID 20207)
-- Name: tape_program_links_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_program_links
    ADD CONSTRAINT tape_program_links_pkey PRIMARY KEY (id);


--
-- TOC entry 83 (OID 20217)
-- Name: vods_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vods
    ADD CONSTRAINT vods_pkey PRIMARY KEY (id);


--
-- TOC entry 84 (OID 20231)
-- Name: broadcast_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY broadcast_logs
    ADD CONSTRAINT broadcast_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 85 (OID 20241)
-- Name: people_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- TOC entry 86 (OID 20243)
-- Name: sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 88 (OID 20245)
-- Name: program_event_links_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY program_event_links
    ADD CONSTRAINT program_event_links_pkey PRIMARY KEY (id);


--
-- TOC entry 89 (OID 20255)
-- Name: vod_group_format_links_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vod_group_format_links
    ADD CONSTRAINT vod_group_format_links_pkey PRIMARY KEY (id);


--
-- TOC entry 90 (OID 20265)
-- Name: reference_log_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY reference_log_entries
    ADD CONSTRAINT reference_log_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 122 (OID 20133)
-- Name: location; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY events
    ADD CONSTRAINT "location" FOREIGN KEY (location_id) REFERENCES locations(id);


--
-- TOC entry 123 (OID 20137)
-- Name: event_type; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY events
    ADD CONSTRAINT event_type FOREIGN KEY (event_type_id) REFERENCES event_types(id);


--
-- TOC entry 124 (OID 20141)
-- Name: file_location; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY events
    ADD CONSTRAINT file_location FOREIGN KEY (file_location_id) REFERENCES file_locations(id);


--
-- TOC entry 125 (OID 20147)
-- Name: owner; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY programs
    ADD CONSTRAINT "owner" FOREIGN KEY (owner_id) REFERENCES users(id);


--
-- TOC entry 126 (OID 20151)
-- Name: status; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY programs
    ADD CONSTRAINT status FOREIGN KEY (status_id) REFERENCES program_statuses(id);


--
-- TOC entry 127 (OID 20155)
-- Name: file_location; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY programs
    ADD CONSTRAINT file_location FOREIGN KEY (file_location_id) REFERENCES file_locations(id);


--
-- TOC entry 128 (OID 20159)
-- Name: vod_group; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY programs
    ADD CONSTRAINT vod_group FOREIGN KEY (vod_group_id) REFERENCES vod_groups(id);


--
-- TOC entry 129 (OID 20165)
-- Name: category; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tapes
    ADD CONSTRAINT category FOREIGN KEY (category_id) REFERENCES tape_categories(id);


--
-- TOC entry 130 (OID 20169)
-- Name: media; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tapes
    ADD CONSTRAINT media FOREIGN KEY (media_id) REFERENCES tape_medias(id);


--
-- TOC entry 131 (OID 20173)
-- Name: owner; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tapes
    ADD CONSTRAINT "owner" FOREIGN KEY (owner_id) REFERENCES users(id);


--
-- TOC entry 132 (OID 20179)
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY playlists
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- TOC entry 133 (OID 20183)
-- Name: channel; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY playlists
    ADD CONSTRAINT channel FOREIGN KEY (channel_id) REFERENCES channels(id);


--
-- TOC entry 134 (OID 20189)
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY program_descriptions
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- TOC entry 135 (OID 20193)
-- Name: language; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY program_descriptions
    ADD CONSTRAINT "language" FOREIGN KEY (language_id) REFERENCES languages(id);


--
-- TOC entry 136 (OID 20199)
-- Name: tape; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_event_links
    ADD CONSTRAINT tape FOREIGN KEY (tape_id) REFERENCES tapes(id);


--
-- TOC entry 137 (OID 20203)
-- Name: event; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_event_links
    ADD CONSTRAINT event FOREIGN KEY (event_id) REFERENCES events(id);


--
-- TOC entry 138 (OID 20209)
-- Name: tape; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_program_links
    ADD CONSTRAINT tape FOREIGN KEY (tape_id) REFERENCES tapes(id);


--
-- TOC entry 139 (OID 20213)
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY tape_program_links
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- TOC entry 140 (OID 20219)
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vods
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- TOC entry 141 (OID 20223)
-- Name: file_location; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vods
    ADD CONSTRAINT file_location FOREIGN KEY (file_location_id) REFERENCES file_locations(id);


--
-- TOC entry 142 (OID 20227)
-- Name: vod_format; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vods
    ADD CONSTRAINT vod_format FOREIGN KEY (vod_format_id) REFERENCES vod_formats(id);


--
-- TOC entry 143 (OID 20233)
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY broadcast_logs
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- TOC entry 144 (OID 20237)
-- Name: channel; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY broadcast_logs
    ADD CONSTRAINT channel FOREIGN KEY (channel_id) REFERENCES channels(id);


--
-- TOC entry 145 (OID 20247)
-- Name: program; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY program_event_links
    ADD CONSTRAINT program FOREIGN KEY (program_id) REFERENCES programs(id);


--
-- TOC entry 146 (OID 20251)
-- Name: event; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY program_event_links
    ADD CONSTRAINT event FOREIGN KEY (event_id) REFERENCES events(id);


--
-- TOC entry 147 (OID 20257)
-- Name: vod_group; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vod_group_format_links
    ADD CONSTRAINT vod_group FOREIGN KEY (vod_group_id) REFERENCES vod_groups(id);


--
-- TOC entry 148 (OID 20261)
-- Name: vod_format; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY vod_group_format_links
    ADD CONSTRAINT vod_format FOREIGN KEY (vod_format_id) REFERENCES vod_formats(id);


--
-- TOC entry 149 (OID 20267)
-- Name: tape; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY reference_log_entries
    ADD CONSTRAINT tape FOREIGN KEY (tape_id) REFERENCES tapes(id);


--
-- TOC entry 150 (OID 20271)
-- Name: channel; Type: FK CONSTRAINT; Schema: public; Owner: elaine2
--

ALTER TABLE ONLY reference_log_entries
    ADD CONSTRAINT channel FOREIGN KEY (channel_id) REFERENCES channels(id);


--
-- TOC entry 36 (OID 19011)
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('users_id_seq', 55, true);


--
-- TOC entry 37 (OID 19022)
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('permissions_id_seq', 278, true);


--
-- TOC entry 38 (OID 19037)
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('roles_id_seq', 6, true);


--
-- TOC entry 39 (OID 19045)
-- Name: tape_medias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('tape_medias_id_seq', 5, true);


--
-- TOC entry 40 (OID 19053)
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('locations_id_seq', 5, true);


--
-- TOC entry 41 (OID 19061)
-- Name: vod_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('vod_groups_id_seq', 3, true);


--
-- TOC entry 42 (OID 19069)
-- Name: vod_formats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('vod_formats_id_seq', 10, true);


--
-- TOC entry 43 (OID 19077)
-- Name: program_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('program_statuses_id_seq', 3, true);


--
-- TOC entry 44 (OID 19085)
-- Name: event_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('event_types_id_seq', 2, true);


--
-- TOC entry 45 (OID 19093)
-- Name: channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('channels_id_seq', 2, true);


--
-- TOC entry 46 (OID 19101)
-- Name: tape_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('tape_categories_id_seq', 2, true);


--
-- TOC entry 47 (OID 19109)
-- Name: languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('languages_id_seq', 2, true);


--
-- TOC entry 48 (OID 19115)
-- Name: file_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('file_locations_id_seq', 5, true);


--
-- TOC entry 49 (OID 19123)
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('events_id_seq', 260, true);


--
-- TOC entry 50 (OID 19132)
-- Name: programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('programs_id_seq', 253, true);


--
-- TOC entry 51 (OID 19141)
-- Name: tapes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('tapes_id_seq', 56, true);


--
-- TOC entry 52 (OID 19151)
-- Name: playlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('playlists_id_seq', 339, true);


--
-- TOC entry 53 (OID 19157)
-- Name: program_descriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('program_descriptions_id_seq', 506, true);


--
-- TOC entry 54 (OID 19166)
-- Name: tape_event_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('tape_event_links_id_seq', 16, true);


--
-- TOC entry 55 (OID 19171)
-- Name: tape_program_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('tape_program_links_id_seq', 49, true);


--
-- TOC entry 56 (OID 19176)
-- Name: vods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('vods_id_seq', 1095, true);


--
-- TOC entry 57 (OID 19181)
-- Name: broadcast_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('broadcast_logs_id_seq', 13, true);


--
-- TOC entry 58 (OID 19187)
-- Name: people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('people_id_seq', 3, true);


--
-- TOC entry 59 (OID 19192)
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('sessions_id_seq', 1742588, true);


--
-- TOC entry 60 (OID 19200)
-- Name: program_event_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('program_event_links_id_seq', 357, true);


--
-- TOC entry 61 (OID 19205)
-- Name: vod_group_format_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('vod_group_format_links_id_seq', 10, true);


--
-- TOC entry 62 (OID 19210)
-- Name: reference_log_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: elaine2
--

SELECT pg_catalog.setval('reference_log_entries_id_seq', 1, false);


SET SESSION AUTHORIZATION 'postgres';

--
-- TOC entry 3 (OID 2200)
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


